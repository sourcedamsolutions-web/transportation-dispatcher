Transportation Dispatcher – MVP v1.0 (Production Package)

Admin User:
Name: Ray
PIN: 619511

This package is preconfigured for Render deployment.

DEPLOYMENT (NO CODING):
1. Go to https://render.com
2. Click New → Web Service
3. Choose 'Upload from computer'
4. Upload this ZIP file
5. Click Deploy

After deploy:
- Open the provided URL
- Login with Admin credentials above
- Add dispatchers/supervisors via Admin panel

This MVP includes:
- PIN-based authentication
- Role-based access
- Day Sheet board (AM yellow / PM orange)
- Printable portrait output
